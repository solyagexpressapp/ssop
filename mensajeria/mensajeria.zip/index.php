
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=inicio.php">
<title>INPOSDOM</title>
<script language="javascript">
    window.location.href = "inicio.php"
</script>
</head>
<body>
Vamos a <a href="inicio.php">inicio.php</a>
</body>
</html>
