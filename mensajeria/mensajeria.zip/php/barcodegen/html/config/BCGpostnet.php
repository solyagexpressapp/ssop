<?php
$classFile = 'BCGpostnet.barcode.php';
$className = 'BCGpostnet';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.2.0';
?>