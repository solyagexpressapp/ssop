<?php
  header("location: ../");
	
?>